class LoginController < ApplicationController
  def login
  end

end
