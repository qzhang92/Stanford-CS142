# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Netslip::Application.config.secret_token = '02f45a8d3a0b28f019e6a55f3a51c79f2fcf391d7fbaacc98dc2d4955ec3ed505ccd34a389e7d62f0bd84487236f6cefb2e332e9704ea6676b0dfbcbc044d3f2'
